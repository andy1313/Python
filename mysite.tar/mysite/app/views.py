from django.shortcuts import render
from django.http import HttpResponse
from .models import Product
from django.template import loader

# Create your views here.

	
def detail(request, product_id):
    return HttpResponse("You're looking at product %s." % product_id)
	
def index(request):
    latest_product_list = Product.objects.order_by('-last_update')[:5]
    template = loader.get_template('app/index.html')
    context = {
        'latest_product_list': latest_product_list,
    }
    return HttpResponse(template.render(context, request))
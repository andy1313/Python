import datetime

from django.db import models
from django.utils import timezone



# Create your models here.
# pythondjango password


class Category(models.Model):
    category_name = models.CharField(max_length=50) 
    def __str__(self):
        return self.category_name
  

class Product(models.Model):
    product_name = models.CharField(max_length=100)
    product_size = models.CharField(max_length=100, blank=True, null=True)
    product_colour = models.CharField(max_length=100, blank=True, null=True)
    product_fabric = models.CharField(max_length=100, blank=True, null=True)
    product_model = models.CharField(max_length=100, blank=True, null=True)
    product_description = models.CharField(max_length=100, blank=True, null=True)
    last_update = models.DateTimeField()
    product_price = models.DecimalField(decimal_places=2,max_digits=5)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)		
    def __str__(self):
        return self.product_name
    def was_updated_recently(self):
        return self.last_update >= timezone.now() - datetime.timedelta(days=1)




class Dealer(models.Model):
    address = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    company = models.CharField(max_length=100)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    def __str__(self):
        return self.name


class Shop(models.Model):
    address = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    dealer = models.ForeignKey(Dealer, on_delete=models.CASCADE)
    def __str__(self):
        return self.name
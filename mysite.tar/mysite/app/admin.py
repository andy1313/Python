from django.contrib import admin
import requests
import json

from .models import Product, Category, Dealer, Shop
# Register your models here.

		
class ProductAdmin(admin.ModelAdmin):
    url= 'erp.com'
    data = serializers.serialize('json', self.get_queryset())
    data = {"new product added" }
    data_json = json.dumps(data)
    response = requests.post(url, data=data_json)
	
admin.site.register(Product)
admin.site.register(Category)
admin.site.register(Dealer)
admin.site.register(Shop)
